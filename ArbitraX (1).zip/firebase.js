
// Configuración inicial de Firebase
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "arbitrax.firebaseapp.com",
  projectId: "arbitrax",
  storageBucket: "arbitrax.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
firebase.initializeApp(firebaseConfig);
